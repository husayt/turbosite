# CHANGELOG.md

## [2.0.0] - 2023-12-11

- Added 7 new pages
- Update Next.js to 14

## [1.1.2] - 2023-10-04

- Update Twitter icon
- Update dependencies

## [1.1.0] - 2023-06-20

- Fix issue with Google Fonts

## [1.0.3] - 2023-05-15

- Fix issue with clients carousel

## [1.0.2] - 2023-05-06

- Dependencies update

## [1.0.1] - 2023-05-06

- Dependencies update

## [1.0.0] - 2023-04-19

First release
